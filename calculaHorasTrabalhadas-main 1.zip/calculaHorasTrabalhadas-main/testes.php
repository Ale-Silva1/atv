<?php
    
    require_once 'index.php';

    // TC01 - Caso Feliz
    function HorasTrabalhadasTestDeveRetornar8(){
        $teste = new HorasTrabalhadas();
        $resultado = $teste->calculaHorasTrabalhadas(8, 17, true);
        echo "Teste de caso feliz: " . $resultado . "\n";
    }
    HorasTrabalhadasTestDeveRetornar8();

    // TC02 - Caso Feliz
    function HorasTrabalhadasTestDeveRetornar4(){
        $teste = new HorasTrabalhadas();
        $resultado = $teste->calculaHorasTrabalhadas(8, 12, false);
        echo "Teste de caso feliz: " . $resultado . "\n";
    }
    HorasTrabalhadasTestDeveRetornar4();

    // TC03 - Caso de Borda
    function HorasTrabalhadasTestDeveRetornar1(){
        $teste = new HorasTrabalhadas();
        $resultado = $teste->calculaHorasTrabalhadas(8, 9, false);
        echo "Teste de caso de borda: " . $resultado . "\n";
    }
    HorasTrabalhadasTestDeveRetornar1();

    // TC04 - Caso de Borda
    function HorasTrabalhadasTestDeveRetornar12(){
        $teste = new HorasTrabalhadas();
        $resultado = $teste->calculaHorasTrabalhadas(7, 19, false);
        echo "Teste de caso de borda: " . $resultado . "\n";
    }
    HorasTrabalhadasTestDeveRetornar12();

    // TC05 - Entrada Inválida
    function HorasTrabalhadasTestDeveRetornarErroEntradaInvalida(){
        $teste = new HorasTrabalhadas();
        $resultado = $teste->calculaHorasTrabalhadas(25, 10, false);
        echo "Teste de entrada invalida: " . $resultado . "\n";
    }
    HorasTrabalhadasTestDeveRetornarErroEntradaInvalida();

    // TC06 - Entrada Inválida
    function HorasTrabalhadasTestDeveRetornarErroSaidaMenorEntrada(){
        $teste = new HorasTrabalhadas();
        $resultado = $teste->calculaHorasTrabalhadas(17, 8, false);
        echo "Teste de entrada invalida: " . $resultado . "\n";
    }
    HorasTrabalhadasTestDeveRetornarErroSaidaMenorEntrada();

    // TC07 - Combinação
    function HorasTrabalhadasTestDeveRetornarErroJornadaMaior12h(){
        $teste = new HorasTrabalhadas();
        $resultado = $teste->calculaHorasTrabalhadas(6, 20, false);
        echo "Teste de combinacao: " . $resultado . "\n";
    }
    HorasTrabalhadasTestDeveRetornarErroJornadaMaior12h();

    // TC08 - Combinação
    function HorasTrabalhadasTestDeveRetornarErroJornadaMenor1h(){
        $teste = new HorasTrabalhadas();
        $resultado = $teste->calculaHorasTrabalhadas(8, 9, true);
        echo "Teste de combinacao: " . $resultado . "\n";
    }
    HorasTrabalhadasTestDeveRetornarErroJornadaMenor1h();

?>